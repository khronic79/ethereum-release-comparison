//! Geth call tracer types.

use crate::parity::{ActionType, CallType, CreationMethod, LocalizedTransactionTrace};
use alloy_primitives::{Address, Bytes, Selector, B256, U256};
use serde::{Deserialize, Serialize};

/// The response object for `debug_traceTransaction` with `"tracer": "callTracer"`.
///
/// <https://github.com/ethereum/go-ethereum/blob/91cb6f863a965481e51d5d9c0e5ccd54796fd967/eth/tracers/native/call.go#L44>
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct CallFrame {
    /// The address of that initiated the call.
    pub from: Address,
    /// Gas allowance before the call. For nested frames, regular gas excluding the EIP-8037
    /// reservoir. The reservoir is passed separately in full, outside the regular-gas 63/64
    /// rule. The top-level frame describes the transaction; do not interpret this as a
    /// per-frame combined budget.
    #[serde(default)]
    pub gas: U256,
    /// Gas used by this call, including nested execution; do not sum parents and their children.
    /// On the top-level transaction frame this is receipt gas, including both EIP-8037 dimensions,
    /// after refunds and the calldata floor. Do not add `state_gas_used` to that total.
    /// Nested-frame gas semantics vary by client and are not a transaction fee or gas-limit
    /// estimate. See the [tracing schema proposal](https://github.com/ethereum/execution-apis/pull/852).
    #[serde(default, rename = "gasUsed")]
    pub gas_used: U256,
    /// Regular (execution) gas contribution to block accounting, excluding EIP-8037 state gas.
    ///
    /// Includes intrinsic gas and the execution-dimension calldata floor; before ordinary refunds
    /// under EIP-7778. This is not receipt gas. See the
    /// [gas accounting guide](crate::geth::state_gas) and
    /// [EIP-8037](https://eips.ethereum.org/EIPS/eip-8037).
    ///
    /// A transaction summary on the top-level frame when supported; not a per-child breakdown.
    /// `None` means not reported (for example, a nested frame, older fork, or unsupported node).
    #[serde(
        default,
        rename = "executionGasUsed",
        alias = "regularGasUsed",
        skip_serializing_if = "Option::is_none"
    )]
    pub execution_gas_used: Option<U256>,
    /// Net EIP-8037 state gas for the whole transaction, excluding regular execution gas.
    ///
    /// Includes state creation charges after state refills and rollback, not peak state gas
    /// demand. Do not subtract `gas_refund` or `state_gas_refund` from this already-net
    /// transaction value. Zero when reported for an inactive EIP-8037 fork; `None` means the
    /// node did not report it. See [EIP-8037](https://eips.ethereum.org/EIPS/eip-8037).
    /// This transaction summary is reported on the top-level frame when supported.
    #[serde(default, rename = "stateGasUsed", skip_serializing_if = "Option::is_none")]
    pub state_gas_used: Option<U256>,
    /// Ordinary transaction refund reported after transaction-boundary refund processing.
    ///
    /// Subject to the [EIP-3529](https://eips.ethereum.org/EIPS/eip-3529) cap; not a raw frame counter.
    /// Excludes EIP-8037 state refills and unused gas. The calldata floor can limit the fee
    /// saving; use the transaction's receipt gas for the final charge. `None` means not
    /// reported. This transaction summary is reported on the top-level frame when supported.
    #[serde(default, rename = "gasRefund", skip_serializing_if = "Option::is_none")]
    pub gas_refund: Option<U256>,
    /// Total EIP-8037 state gas refilled within the transaction, which the proposal calls
    /// "source-based state-gas refunds". Already netted out of `state_gas_used`; do not subtract
    /// it again. Optional in the proposal and only meaningful on the top-level frame; `None`
    /// means not reported. See [EIP-8037](https://eips.ethereum.org/EIPS/eip-8037).
    #[serde(default, rename = "stateGasRefund", skip_serializing_if = "Option::is_none")]
    pub state_gas_refund: Option<U256>,
    /// The address of the contract that was called.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub to: Option<Address>,
    /// Calldata input.
    pub input: Bytes,
    /// Output of the call, if any.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub output: Option<Bytes>,
    /// Error message, if any.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
    /// Why this call reverted, if it reverted.
    #[serde(default, rename = "revertReason", skip_serializing_if = "Option::is_none")]
    pub revert_reason: Option<String>,
    /// Recorded child calls.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub calls: Vec<Self>,
    /// Logs emitted by this call.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub logs: Vec<CallLogFrame>,
    /// Value transferred.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub value: Option<U256>,
    /// The type of the call.
    #[serde(rename = "type")]
    pub typ: String,
}

impl CallFrame {
    /// Returns an iterator over this frame and all nested child frames in depth-first pre-order.
    ///
    /// Use [`CallFrameIter::skip_children`] to avoid descending into the children of the most
    /// recently yielded frame.
    ///
    /// # Examples
    ///
    /// Iterate over all frames:
    /// ```
    /// # use alloy_rpc_types_trace::geth::CallFrame;
    /// # let frame = CallFrame::default();
    /// for call in frame.iter() {
    ///     println!("{} -> {:?}", call.from, call.to);
    /// }
    /// ```
    ///
    /// Skip child calls selectively:
    /// ```
    /// # use alloy_rpc_types_trace::geth::CallFrame;
    /// # let frame = CallFrame::default();
    /// let mut iter = frame.iter();
    /// while let Some(call) = iter.next() {
    ///     if call.is_static_call() {
    ///         iter.skip_children(); // don't descend into static calls
    ///     }
    /// }
    /// ```
    pub fn iter(&self) -> CallFrameIter<'_> {
        CallFrameIter::new(self)
    }

    /// Returns the first four bytes of calldata, or `None` if the input is shorter.
    pub fn selector(&self) -> Option<Selector> {
        if self.input.len() < 4 {
            return None;
        }
        Some(Selector::from_slice(&self.input[..4]))
    }

    /// Returns true if this call reverted.
    pub fn is_revert(&self) -> bool {
        if self.revert_reason.is_some() {
            return true;
        }
        matches!(self.error.as_deref(), Some("execution reverted"))
    }

    /// Returns true if this is a regular call
    pub fn is_call(&self) -> bool {
        self.typ == CallKind::Call
    }

    /// Returns true if this is a delegate call
    pub fn is_delegate_call(&self) -> bool {
        self.typ == CallKind::DelegateCall
    }

    /// Returns true if this is a static call
    pub fn is_static_call(&self) -> bool {
        self.typ == CallKind::StaticCall
    }

    /// Returns true if this is a auth call
    pub fn is_auth_call(&self) -> bool {
        self.typ == CallKind::AuthCall
    }
}

/// Represents a recorded log that is emitted during a trace call.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct CallLogFrame {
    /// The address of the contract that was called.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub address: Option<Address>,
    /// The topics of the log.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub topics: Option<Vec<B256>>,
    /// The data of the log.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub data: Option<Bytes>,
    /// The position of the log relative to subcalls within the same trace.
    #[serde(default, with = "alloy_serde::quantity::opt", skip_serializing_if = "Option::is_none")]
    pub position: Option<u64>,
    /// The index of the log in the trace.
    #[serde(default, with = "alloy_serde::quantity::opt", skip_serializing_if = "Option::is_none")]
    pub index: Option<u64>,
}

impl CallLogFrame {
    /// Converts this log frame into a primitives log object
    pub fn into_log(self) -> alloy_primitives::Log {
        alloy_primitives::Log::new_unchecked(
            self.address.unwrap_or_default(),
            self.topics.unwrap_or_default(),
            self.data.unwrap_or_default(),
        )
    }
}

impl From<CallLogFrame> for alloy_primitives::Log {
    fn from(value: CallLogFrame) -> Self {
        value.into_log()
    }
}

/// The configuration for the call tracer.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CallConfig {
    /// When set to true, this will only trace the primary (top-level) call and not any sub-calls.
    /// It eliminates the additional processing for each call frame.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub only_top_call: Option<bool>,
    /// When set to true, this will include the logs emitted by the call.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub with_log: Option<bool>,
}

impl CallConfig {
    /// Sets the only top call flag.
    pub const fn only_top_call(mut self) -> Self {
        self.only_top_call = Some(true);
        self
    }

    /// Sets the with log flag.
    pub const fn with_log(mut self) -> Self {
        self.with_log = Some(true);
        self
    }
}

/// The response object for `debug_traceTransaction` with `"tracer": "flatCallTracer"`.
///
/// That is equivalent to parity's [`LocalizedTransactionTrace`]
/// <https://github.com/ethereum/go-ethereum/blob/0dd173a727dd2d2409b8e401b22e85d20c25b71f/eth/tracers/native/call_flat.go#L62-L62>
pub type FlatCallFrame = Vec<LocalizedTransactionTrace>;

/// The configuration for the flat call tracer.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FlatCallConfig {
    /// If true, call tracer converts errors to parity format
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub convert_parity_errors: Option<bool>,
    /// If true, call tracer includes calls to precompiled contracts
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub include_precompiles: Option<bool>,
}

impl FlatCallConfig {
    /// Converts errors to parity format.
    pub const fn parity_errors(mut self) -> Self {
        self.convert_parity_errors = Some(true);
        self
    }

    /// Include calls to precompiled contracts.
    pub const fn with_precompiles(mut self) -> Self {
        self.include_precompiles = Some(true);
        self
    }
}

/// A unified representation of a call.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum CallKind {
    /// Represents a regular call.
    #[default]
    Call,
    /// Represents a static call.
    StaticCall,
    /// Represents a call code operation.
    CallCode,
    /// Represents a delegate call.
    DelegateCall,
    /// Represents an authorized call.
    AuthCall,
    /// Represents a contract creation operation.
    Create,
    /// Represents a contract creation operation using the CREATE2 opcode.
    Create2,
}

impl CallKind {
    /// Returns the string representation of the call kind.
    pub const fn to_str(self) -> &'static str {
        match self {
            Self::Call => "CALL",
            Self::StaticCall => "STATICCALL",
            Self::CallCode => "CALLCODE",
            Self::DelegateCall => "DELEGATECALL",
            Self::AuthCall => "AUTHCALL",
            Self::Create => "CREATE",
            Self::Create2 => "CREATE2",
        }
    }

    /// Returns true if the call is a create
    #[inline]
    pub const fn is_any_create(&self) -> bool {
        matches!(self, Self::Create | Self::Create2)
    }

    /// Returns true if the call is a delegate of some sorts
    #[inline]
    pub const fn is_delegate(&self) -> bool {
        matches!(self, Self::DelegateCall | Self::CallCode)
    }

    /// Returns true if the call is [CallKind::StaticCall].
    #[inline]
    pub const fn is_static_call(&self) -> bool {
        matches!(self, Self::StaticCall)
    }

    /// Returns true if the call is [CallKind::AuthCall].
    #[inline]
    pub const fn is_auth_call(&self) -> bool {
        matches!(self, Self::AuthCall)
    }
}

impl core::fmt::Display for CallKind {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str(self.to_str())
    }
}

impl PartialEq<String> for CallKind {
    fn eq(&self, other: &String) -> bool {
        self.to_str() == other.as_str()
    }
}

impl PartialEq<CallKind> for String {
    fn eq(&self, other: &CallKind) -> bool {
        self.as_str() == other.to_str()
    }
}

impl PartialEq<&str> for CallKind {
    fn eq(&self, other: &&str) -> bool {
        self.to_str() == *other
    }
}

impl PartialEq<CallKind> for &str {
    fn eq(&self, other: &CallKind) -> bool {
        *self == other.to_str()
    }
}

impl From<CallKind> for CreationMethod {
    fn from(kind: CallKind) -> Self {
        match kind {
            CallKind::Create => Self::Create,
            CallKind::Create2 => Self::Create2,
            _ => Self::None,
        }
    }
}

impl From<CallKind> for ActionType {
    fn from(kind: CallKind) -> Self {
        match kind {
            CallKind::Call
            | CallKind::StaticCall
            | CallKind::DelegateCall
            | CallKind::CallCode
            | CallKind::AuthCall => Self::Call,
            CallKind::Create | CallKind::Create2 => Self::Create,
        }
    }
}

impl From<CallKind> for CallType {
    fn from(ty: CallKind) -> Self {
        match ty {
            CallKind::Call => Self::Call,
            CallKind::StaticCall => Self::StaticCall,
            CallKind::CallCode => Self::CallCode,
            CallKind::DelegateCall => Self::DelegateCall,
            CallKind::Create | CallKind::Create2 => Self::None,
            CallKind::AuthCall => Self::AuthCall,
        }
    }
}

/// An iterator over [`CallFrame`]s in depth-first pre-order.
///
/// Created by [`CallFrame::iter`]. Use [`skip_children`](Self::skip_children) to avoid descending
/// into the children of the most recently yielded frame.
#[derive(Debug, Clone)]
pub struct CallFrameIter<'a> {
    /// Stack of frames yet to be yielded.
    stack: Vec<&'a CallFrame>,
    /// Number of children pushed onto the stack by the last call to `next`.
    last_children_count: usize,
}

impl<'a> CallFrameIter<'a> {
    fn new(frame: &'a CallFrame) -> Self {
        Self { stack: vec![frame], last_children_count: 0 }
    }

    /// Skips the children of the most recently yielded [`CallFrame`].
    ///
    /// Any children that were pushed onto the internal stack by the last call to
    /// [`next`](Iterator::next) are removed, so iteration continues with the next sibling or
    /// ancestor instead.
    ///
    /// Has no effect if called more than once without an intervening `next`, or if the last frame
    /// had no children.
    pub fn skip_children(&mut self) {
        let len = self.stack.len();
        self.stack.truncate(len.saturating_sub(self.last_children_count));
        self.last_children_count = 0;
    }
}

impl<'a> Iterator for CallFrameIter<'a> {
    type Item = &'a CallFrame;

    fn next(&mut self) -> Option<Self::Item> {
        let frame = self.stack.pop()?;
        // Push children in reverse order so the first child is popped first.
        self.stack.extend(frame.calls.iter().rev());
        self.last_children_count = frame.calls.len();
        Some(frame)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::geth::*;
    use similar_asserts::assert_eq;

    // See <https://github.com/ethereum/go-ethereum/tree/master/eth/tracers/internal/tracetest/testdata>
    const DEFAULT: &str = include_str!("../../test_data/call_tracer/default.json");
    const LEGACY: &str = include_str!("../../test_data/call_tracer/legacy.json");
    const ONLY_TOP_CALL: &str = include_str!("../../test_data/call_tracer/only_top_call.json");
    const WITH_LOG: &str = include_str!("../../test_data/call_tracer/with_log.json");

    #[test]
    fn test_serialize_call_trace() {
        let mut opts = GethDebugTracingCallOptions::default();
        opts.tracing_options.config.disable_storage = Some(false);
        opts.tracing_options.tracer =
            Some(GethDebugTracerType::BuiltInTracer(GethDebugBuiltInTracerType::CallTracer));
        opts.tracing_options.tracer_config =
            serde_json::to_value(CallConfig { only_top_call: Some(true), with_log: Some(true) })
                .unwrap()
                .into();

        assert_eq!(
            serde_json::to_string(&opts).unwrap(),
            r#"{"disableStorage":false,"tracer":"callTracer","tracerConfig":{"onlyTopCall":true,"withLog":true}}"#
        );
    }

    #[test]
    fn test_deserialize_call_trace() {
        let _trace: CallFrame = serde_json::from_str(DEFAULT).unwrap();
        let _trace: CallFrame = serde_json::from_str(LEGACY).unwrap();
        let _trace: CallFrame = serde_json::from_str(ONLY_TOP_CALL).unwrap();
        let _trace: CallFrame = serde_json::from_str(WITH_LOG).unwrap();
    }

    #[test]
    fn test_call_log_frame_serde_with_regular_json_number() {
        // Test that CallLogFrame can deserialize index as a regular JSON number
        let json = r#"{
            "address": "0x0000000000000000000000000000000000000000",
            "topics": ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"],
            "data": "0x1234",
            "position": 5,
            "index": 10
        }"#;

        let log_frame: CallLogFrame = serde_json::from_str(json).unwrap();
        assert_eq!(log_frame.position, Some(5));
        assert_eq!(log_frame.index, Some(10));

        // Test serialization back to JSON with quantity format
        let serialized = serde_json::to_string(&log_frame).unwrap();
        let deserialized: CallLogFrame = serde_json::from_str(&serialized).unwrap();
        assert_eq!(log_frame, deserialized);

        // Test with hex values as well
        let json_hex = r#"{
            "address": "0x0000000000000000000000000000000000000000",
            "topics": ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"],
            "data": "0x1234",
            "position": "0x5",
            "index": "0xa"
        }"#;

        let log_frame_hex: CallLogFrame = serde_json::from_str(json_hex).unwrap();
        assert_eq!(log_frame_hex.position, Some(5));
        assert_eq!(log_frame_hex.index, Some(10));
        assert_eq!(log_frame, log_frame_hex);
    }

    /// Helper to build a call frame tree for testing.
    fn make_frame(label: &str, children: Vec<CallFrame>) -> CallFrame {
        CallFrame { typ: label.to_string(), calls: children, ..Default::default() }
    }

    #[test]
    fn test_callframe_iter_all() {
        // Build tree:  A -> [B -> [D, E], C]
        let root = make_frame(
            "A",
            vec![
                make_frame("B", vec![make_frame("D", vec![]), make_frame("E", vec![])]),
                make_frame("C", vec![]),
            ],
        );

        let labels: Vec<&str> = root.iter().map(|f| f.typ.as_str()).collect();
        assert_eq!(labels, vec!["A", "B", "D", "E", "C"]);
    }

    #[test]
    fn test_callframe_iter_skip_children() {
        // Build tree:  A -> [B -> [D, E], C]
        let root = make_frame(
            "A",
            vec![
                make_frame("B", vec![make_frame("D", vec![]), make_frame("E", vec![])]),
                make_frame("C", vec![]),
            ],
        );

        let mut labels = Vec::new();
        let mut iter = root.iter();
        while let Some(frame) = iter.next() {
            labels.push(frame.typ.as_str());
            if frame.typ == "B" {
                iter.skip_children(); // skip D and E
            }
        }
        assert_eq!(labels, vec!["A", "B", "C"]);
    }

    #[test]
    fn test_callframe_iter_single() {
        let root = make_frame("root", vec![]);
        let labels: Vec<&str> = root.iter().map(|f| f.typ.as_str()).collect();
        assert_eq!(labels, vec!["root"]);
    }

    #[test]
    fn test_callframe_iter_skip_root_children() {
        let root = make_frame("A", vec![make_frame("B", vec![]), make_frame("C", vec![])]);

        let mut iter = root.iter();
        let first = iter.next().unwrap();
        assert_eq!(first.typ, "A");
        iter.skip_children();
        assert!(iter.next().is_none());
    }
}
