//! Geth tracing types.

use crate::geth::{
    call::FlatCallFrame,
    erc7562::{Erc7562Config, Erc7562Frame},
    mux::{MuxConfig, MuxFrame},
};
use alloy_primitives::{Bytes, B256, U256};
use alloy_rpc_types_eth::{state::StateOverride, BlockOverrides};
use serde::{de::DeserializeOwned, ser::SerializeMap, Deserialize, Serialize, Serializer};
use std::{borrow::Cow, collections::BTreeMap, time::Duration};
// re-exports
pub use self::{
    call::{CallConfig, CallFrame, CallKind, CallLogFrame, FlatCallConfig},
    four_byte::FourByteFrame,
    noop::NoopFrame,
    pre_state::{
        AccountChangeKind, AccountState, DiffMode, DiffStateKind, PreStateConfig, PreStateFrame,
        PreStateMode,
    },
    state_gas::StateGasTrace,
};

pub mod call;
pub mod erc7562;
pub mod four_byte;
pub mod mux;
pub mod noop;
pub mod pre_state;
pub mod state_gas;

/// Error when the inner tracer from [GethTrace] is mismatching to the target tracer.
#[derive(Debug, thiserror::Error)]
#[error("unexpected tracer")]
pub struct UnexpectedTracerError(pub GethTrace);

/// Result type for geth style transaction trace
pub type TraceResult = crate::common::TraceResult<GethTrace, String>;

/// blockTraceResult represents the results of tracing a single block when an entire chain is being
/// traced.
///
/// Ref <https://github.com/ethereum/go-ethereum/blob/ee530c0d5aa70d2c00ab5691a89ab431b73f8165/eth/tracers/api.go#L218-L222>
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct BlockTraceResult {
    /// Block number corresponding to the trace task
    pub block: U256,
    /// Block hash corresponding to the trace task
    pub hash: B256,
    /// Trace results produced by the trace task
    pub traces: Vec<TraceResult>,
}

/// Result for one block emitted by a `debug_traceChain` subscription.
///
/// <https://github.com/ethereum/go-ethereum/blob/e25efd2c62175e82b364c0344d77c882aa951f68/eth/tracers/api.go#L190-L196>
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct ChainBlockTraceResult {
    /// Block number corresponding to the trace task.
    pub block: U256,
    /// Block hash corresponding to the trace task.
    pub hash: B256,
    /// Trace results produced by the trace task.
    ///
    /// Geth leaves entries after the first transaction-level tracing failure as `null`.
    pub traces: Vec<Option<TraceResult>>,
}

/// Geth Default struct log trace frame
///
/// <https://github.com/ethereum/go-ethereum/blob/a9ef135e2dd53682d106c6a2aede9187026cc1de/eth/tracers/logger/logger.go#L406-L411>
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DefaultFrame {
    /// Whether the transaction failed
    pub failed: bool,
    /// Total transaction gas charged, matching receipt `gasUsed`.
    /// Includes regular and EIP-8037 state gas, intrinsic costs, refunds, and the calldata floor.
    /// Excludes blob gas. Do not add `state_gas_used` again or use this as a gas-limit estimate.
    pub gas: u64,
    /// Regular (execution) gas contribution to block accounting, excluding EIP-8037 state gas.
    ///
    /// Includes intrinsic gas and the execution-dimension calldata floor; before ordinary refunds
    /// under EIP-7778. This is not receipt gas. See the
    /// [gas accounting guide](crate::geth::state_gas) and
    /// [EIP-8037](https://eips.ethereum.org/EIPS/eip-8037).
    ///
    /// Optional because older forks and nodes can omit this field; `None` does not mean zero.
    #[serde(
        default,
        with = "alloy_serde::quantity::opt",
        rename = "executionGasUsed",
        alias = "regularGasUsed",
        skip_serializing_if = "Option::is_none"
    )]
    pub execution_gas_used: Option<u64>,
    /// Net EIP-8037 state gas for the whole transaction, excluding regular execution gas.
    ///
    /// Includes state creation charges after state refills and rollback, not peak state gas
    /// demand. Do not subtract `gas_refund` from this already-net transaction value.
    /// Zero when reported for an inactive EIP-8037 fork; `None` means the node did not report it.
    /// See [EIP-8037](https://eips.ethereum.org/EIPS/eip-8037).
    #[serde(
        default,
        with = "alloy_serde::quantity::opt",
        rename = "stateGasUsed",
        skip_serializing_if = "Option::is_none"
    )]
    pub state_gas_used: Option<u64>,
    /// Ordinary transaction refund reported after transaction-boundary refund processing.
    ///
    /// Subject to the [EIP-3529](https://eips.ethereum.org/EIPS/eip-3529) cap; not a raw frame counter.
    /// Excludes EIP-8037 state refills and unused gas. The calldata floor can limit the fee
    /// saving; use the transaction's receipt gas for the final charge. `None` means not
    /// reported.
    #[serde(
        default,
        with = "alloy_serde::quantity::opt",
        rename = "gasRefund",
        skip_serializing_if = "Option::is_none"
    )]
    pub gas_refund: Option<u64>,
    /// Output of the transaction
    pub return_value: Bytes,
    /// Recorded traces of the transaction
    pub struct_logs: Vec<StructLog>,
}

/// Represents a struct log entry in a trace
///
/// <https://github.com/ethereum/go-ethereum/blob/366d2169fbc0e0f803b68c042b77b6b480836dbc/eth/tracers/logger/logger.go#L413-L426>
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct StructLog {
    /// program counter
    pub pc: u64,
    /// opcode to be executed
    pub op: Cow<'static, str>,
    /// Regular gas remaining before this opcode, excluding the EIP-8037 state gas reservoir.
    /// This is the `GAS`/`gasleft()` dimension. State charges can spill into it and refills can
    /// raise it. See [EIP-8037](https://eips.ethereum.org/EIPS/eip-8037).
    pub gas: u64,
    /// Gas charged to the regular gas counter for this opcode.
    /// Under EIP-8037 this can include state gas spilling out of an empty reservoir; it excludes
    /// state gas paid from the reservoir. It is not necessarily a pure execution-gas charge.
    /// Do not blindly add `state_gas_cost`, which can overlap with spillover.
    #[serde(rename = "gasCost")]
    pub gas_cost: u64,
    /// Net EIP-8037 state gas charged by this opcode, regardless of which gas pool paid it.
    /// Positive means a charge; negative means a state refill, not an EIP-3529 refund.
    /// `None` means not reported. Summing steps cannot reconstruct transaction state gas:
    /// account creation, code deposit, authorization processing, and rollback can occur outside
    /// steps. See [EIP-8037](https://eips.ethereum.org/EIPS/eip-8037).
    #[serde(default, rename = "stateGasCost", skip_serializing_if = "Option::is_none")]
    pub state_gas_cost: Option<i64>,
    /// EIP-8037 state gas reservoir remaining before this opcode, excluded from `gas`.
    /// State charges spend it first, then spill into regular gas. Regular execution cannot spend
    /// it. It is passed to child frames in full, outside the 63/64 rule; it is not a per-call
    /// gas limit. `Some(0)` means an empty reservoir, not that state gas is disabled. `None`
    /// means not reported. See [EIP-8037](https://eips.ethereum.org/EIPS/eip-8037).
    #[serde(default, rename = "stateGasReservoir", skip_serializing_if = "Option::is_none")]
    pub state_gas_reservoir: Option<u64>,
    /// Current call depth
    pub depth: u64,
    /// Error message if any
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
    /// EVM stack
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub stack: Option<Vec<U256>>,
    /// Last call's return data. Enabled via enableReturnData
    #[serde(default, rename = "returnData", skip_serializing_if = "Option::is_none")]
    pub return_data: Option<Bytes>,
    /// ref <https://github.com/ethereum/go-ethereum/blob/366d2169fbc0e0f803b68c042b77b6b480836dbc/eth/tracers/logger/logger.go#L450-L452>
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub memory: Option<Vec<String>>,
    /// Size of memory.
    #[serde(default, rename = "memSize", skip_serializing_if = "Option::is_none")]
    pub memory_size: Option<u64>,
    /// Storage slots of current contract read from and written to. Only emitted for SLOAD and
    /// SSTORE. Disabled via disableStorage
    #[serde(
        default,
        skip_serializing_if = "Option::is_none",
        serialize_with = "serialize_string_storage_map_opt"
    )]
    pub storage: Option<BTreeMap<B256, B256>>,
    /// Ordinary transaction refund counter at this step, before the transaction-wide cap/floor.
    /// Excludes EIP-8037 state refills. This is not the applied refund or available execution gas.
    #[serde(default, rename = "refund", skip_serializing_if = "Option::is_none")]
    pub refund_counter: Option<u64>,
}

impl StructLog {
    /// Returns the name of the opcode.
    pub fn opcode(&self) -> &str {
        self.op.as_ref()
    }
}

/// Tracing response objects
///
/// Note: This deserializes untagged, so it's possible that a custom javascript tracer response
/// matches another variant, for example a js tracer that returns `{}` would be deserialized as
/// [GethTrace::NoopTracer]
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(untagged)]
pub enum GethTrace {
    /// The response for the default struct log tracer
    Default(DefaultFrame),
    /// The response for ERC-7562 tracer
    Erc7562Tracer(Erc7562Frame),
    /// The response for call tracer
    CallTracer(CallFrame),
    /// The response for the flat call tracer
    FlatCallTracer(FlatCallFrame),
    /// The response for four byte tracer
    FourByteTracer(FourByteFrame),
    /// The response for pre-state byte tracer
    PreStateTracer(PreStateFrame),
    /// The response for the EIP-8037 state-gas tracer
    StateGasTracer(StateGasTrace),
    /// An empty json response
    NoopTracer(NoopFrame),
    /// The response for mux tracer
    MuxTracer(MuxFrame),
    /// Any other trace response, such as custom javascript response objects
    JS(serde_json::Value),
}

impl GethTrace {
    /// Returns true if this is a default structlog frame.
    pub const fn is_default(&self) -> bool {
        matches!(self, Self::Default(_))
    }

    /// Returns true if this is a call frame.
    pub const fn is_call(&self) -> bool {
        matches!(self, Self::CallTracer(_))
    }

    /// Returns true if this is a flat call frame.
    pub const fn is_flat_call(&self) -> bool {
        matches!(self, Self::FlatCallTracer(_))
    }

    /// Returns true if this is a four byte frame.
    pub const fn is_four_byte(&self) -> bool {
        matches!(self, Self::FourByteTracer(_))
    }

    /// Returns true if this is a pre-state frame.
    pub const fn is_pre_state(&self) -> bool {
        matches!(self, Self::PreStateTracer(_))
    }

    /// Returns true if this is a state-gas trace.
    pub const fn is_state_gas(&self) -> bool {
        matches!(self, Self::StateGasTracer(_))
    }

    /// Returns true if this is a noop frame.
    pub const fn is_noop(&self) -> bool {
        matches!(self, Self::NoopTracer(_))
    }

    /// Returns true if this is a mux trace.
    pub const fn is_mux(&self) -> bool {
        matches!(self, Self::MuxTracer(_))
    }

    /// Returns true if this is a JS trace
    pub const fn is_js(&self) -> bool {
        matches!(self, Self::JS(_))
    }

    /// Try to convert the inner tracer to [DefaultFrame]
    pub fn try_into_default_frame(self) -> Result<DefaultFrame, UnexpectedTracerError> {
        match self {
            Self::Default(inner) => Ok(inner),
            _ => Err(UnexpectedTracerError(self)),
        }
    }

    /// Try to convert the inner tracer to [CallFrame]
    pub fn try_into_call_frame(self) -> Result<CallFrame, UnexpectedTracerError> {
        match self {
            Self::CallTracer(inner) => Ok(inner),
            _ => Err(UnexpectedTracerError(self)),
        }
    }

    /// Try to convert the inner tracer to [FlatCallFrame]
    pub fn try_into_flat_call_frame(self) -> Result<FlatCallFrame, UnexpectedTracerError> {
        match self {
            Self::FlatCallTracer(inner) => Ok(inner),
            _ => Err(UnexpectedTracerError(self)),
        }
    }

    /// Try to convert the inner tracer to [FourByteFrame]
    pub fn try_into_four_byte_frame(self) -> Result<FourByteFrame, UnexpectedTracerError> {
        match self {
            Self::FourByteTracer(inner) => Ok(inner),
            _ => Err(UnexpectedTracerError(self)),
        }
    }

    /// Try to convert the inner tracer to [PreStateFrame]
    pub fn try_into_pre_state_frame(self) -> Result<PreStateFrame, UnexpectedTracerError> {
        match self {
            Self::PreStateTracer(inner) => Ok(inner),
            _ => Err(UnexpectedTracerError(self)),
        }
    }

    /// Try to convert the inner tracer to [StateGasTrace]
    pub fn try_into_state_gas_trace(self) -> Result<StateGasTrace, UnexpectedTracerError> {
        match self {
            Self::StateGasTracer(inner) => Ok(inner),
            _ => Err(UnexpectedTracerError(self)),
        }
    }

    /// Try to convert the inner tracer to [NoopFrame]
    pub fn try_into_noop_frame(self) -> Result<NoopFrame, UnexpectedTracerError> {
        match self {
            Self::NoopTracer(inner) => Ok(inner),
            _ => Err(UnexpectedTracerError(self)),
        }
    }

    /// Try to convert the inner tracer to [MuxFrame]
    pub fn try_into_mux_frame(self) -> Result<MuxFrame, UnexpectedTracerError> {
        match self {
            Self::MuxTracer(inner) => Ok(inner),
            _ => Err(UnexpectedTracerError(self)),
        }
    }

    /// Try to convert the inner tracer to [Erc7562Frame]
    pub fn try_into_erc7562_frame(self) -> Result<Erc7562Frame, UnexpectedTracerError> {
        match self {
            Self::Erc7562Tracer(inner) => Ok(inner),
            _ => Err(UnexpectedTracerError(self)),
        }
    }

    /// Try to convert the inner tracer to [serde_json::Value]
    pub fn try_into_json_value(self) -> Result<serde_json::Value, UnexpectedTracerError> {
        match self {
            Self::JS(inner) => Ok(inner),
            _ => Err(UnexpectedTracerError(self)),
        }
    }
}

impl Default for GethTrace {
    fn default() -> Self {
        Self::Default(DefaultFrame::default())
    }
}

impl From<DefaultFrame> for GethTrace {
    fn from(value: DefaultFrame) -> Self {
        Self::Default(value)
    }
}

impl From<FourByteFrame> for GethTrace {
    fn from(value: FourByteFrame) -> Self {
        Self::FourByteTracer(value)
    }
}

impl From<CallFrame> for GethTrace {
    fn from(value: CallFrame) -> Self {
        Self::CallTracer(value)
    }
}

impl From<FlatCallFrame> for GethTrace {
    fn from(value: FlatCallFrame) -> Self {
        Self::FlatCallTracer(value)
    }
}

impl From<PreStateFrame> for GethTrace {
    fn from(value: PreStateFrame) -> Self {
        Self::PreStateTracer(value)
    }
}

impl From<StateGasTrace> for GethTrace {
    fn from(value: StateGasTrace) -> Self {
        Self::StateGasTracer(value)
    }
}

impl From<NoopFrame> for GethTrace {
    fn from(value: NoopFrame) -> Self {
        Self::NoopTracer(value)
    }
}

impl From<MuxFrame> for GethTrace {
    fn from(value: MuxFrame) -> Self {
        Self::MuxTracer(value)
    }
}

impl From<Erc7562Frame> for GethTrace {
    fn from(value: Erc7562Frame) -> Self {
        Self::Erc7562Tracer(value)
    }
}

/// Available built-in tracers
///
/// See <https://geth.ethereum.org/docs/developers/evm-tracing/built-in-tracers>
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum GethDebugBuiltInTracerType {
    /// The 4byteTracer collects the function selectors of every function executed in the lifetime
    /// of a transaction, along with the size of the supplied call data. The result is a
    /// [FourByteFrame] where the keys are SELECTOR-CALLDATASIZE and the values are number of
    /// occurrences of this key.
    #[serde(rename = "4byteTracer")]
    FourByteTracer,
    /// The callTracer tracks all the call frames executed during a transaction, including depth 0.
    /// The result will be a nested list of call frames, resembling how EVM works. They form a tree
    /// with the top-level call at root and sub-calls as children of the higher levels.
    #[serde(rename = "callTracer")]
    CallTracer,
    /// Tracks all call frames of a transaction and returns them in a flat format, i.e. as opposed
    /// to the nested format of `callTracer`.
    #[serde(rename = "flatCallTracer")]
    FlatCallTracer,
    /// The prestate tracer operates in two distinct modes: prestate and diff.
    /// - In prestate mode, it retrieves the accounts required for executing a specified
    ///   transaction.
    /// - In diff mode, it identifies the changes between the transaction's initial and final
    ///   states, detailing the modifications caused by the transaction.
    ///
    /// By default, the prestateTracer is set to prestate mode. It reexecutes the given transaction
    /// and tracks every part of state that is accessed.
    ///
    /// This functionality is akin to a stateless witness, with the key distinction that this
    /// tracer does not provide any cryptographic proofs; it only returns the trie leaves.
    /// The output is an object where the keys correspond to account addresses.
    #[serde(rename = "prestateTracer")]
    PreStateTracer,
    /// The EIP-8037 state-gas summary tracer.
    #[serde(rename = "stateGasTracer")]
    StateGasTracer,
    /// This tracer is a noop. It returns an empty object and is only meant for testing the setup.
    #[serde(rename = "noopTracer")]
    NoopTracer,
    /// The mux tracer is a tracer that can run multiple tracers at once.
    #[serde(rename = "muxTracer")]
    MuxTracer,
    /// The ERC-7562 tracer that checks validation rules defined in ERC-7562 (for ERC-4337 and
    /// RIP-7560)
    #[serde(rename = "erc7562Tracer")]
    Erc7562Tracer,
}

/// Available tracers
///
/// See <https://geth.ethereum.org/docs/developers/evm-tracing/built-in-tracers> and <https://geth.ethereum.org/docs/developers/evm-tracing/custom-tracer>
#[derive(Clone, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(untagged)]
pub enum GethDebugTracerType {
    /// built-in tracer
    BuiltInTracer(GethDebugBuiltInTracerType),
    /// custom JS tracer
    JsTracer(String),
}

impl GethDebugTracerType {
    /// Returns true if this a [`GethDebugTracerType::JsTracer`] variant.
    pub const fn is_js(&self) -> bool {
        matches!(self, Self::JsTracer(_))
    }

    /// Returns the tracer type as a string.
    ///
    /// If this is not a builtin tracer, it returns the captured string, which could be JavaScript
    /// code or a custom identifier such as `"tracer": "stylusTracer"`
    pub fn as_str(&self) -> &str {
        match self {
            Self::BuiltInTracer(tracer) => match tracer {
                GethDebugBuiltInTracerType::FourByteTracer => "4byteTracer",
                GethDebugBuiltInTracerType::CallTracer => "callTracer",
                GethDebugBuiltInTracerType::FlatCallTracer => "flatCallTracer",
                GethDebugBuiltInTracerType::PreStateTracer => "prestateTracer",
                GethDebugBuiltInTracerType::StateGasTracer => "stateGasTracer",
                GethDebugBuiltInTracerType::NoopTracer => "noopTracer",
                GethDebugBuiltInTracerType::MuxTracer => "muxTracer",
                GethDebugBuiltInTracerType::Erc7562Tracer => "erc7562Tracer",
            },
            Self::JsTracer(code) => code,
        }
    }
}

impl From<GethDebugBuiltInTracerType> for GethDebugTracerType {
    fn from(value: GethDebugBuiltInTracerType) -> Self {
        Self::BuiltInTracer(value)
    }
}

/// Configuration of the tracer
///
/// This is a simple wrapper around serde_json::Value.
/// with helpers for deserializing tracer configs.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(transparent)]
pub struct GethDebugTracerConfig(pub serde_json::Value);

// === impl GethDebugTracerConfig ===

impl GethDebugTracerConfig {
    /// Returns if this is a null object
    pub fn is_null(&self) -> bool {
        self.0.is_null()
    }

    /// Consumes the config and tries to deserialize it into the given type.
    pub fn from_value<T: DeserializeOwned>(self) -> Result<T, serde_json::Error> {
        serde_json::from_value(self.0)
    }

    /// Returns the [CallConfig] if it is a call config.
    pub fn into_call_config(self) -> Result<CallConfig, serde_json::Error> {
        if self.0.is_null() {
            return Ok(Default::default());
        }
        self.from_value()
    }

    /// Returns the [FlatCallConfig] if it is a call config.
    pub fn into_flat_call_config(self) -> Result<FlatCallConfig, serde_json::Error> {
        if self.0.is_null() {
            return Ok(Default::default());
        }
        self.from_value()
    }

    /// Returns the raw json value
    pub fn into_json(self) -> serde_json::Value {
        self.0
    }

    /// Returns the [PreStateConfig] if it is a prestate config.
    pub fn into_pre_state_config(self) -> Result<PreStateConfig, serde_json::Error> {
        if self.0.is_null() {
            return Ok(Default::default());
        }
        self.from_value()
    }

    /// Returns the [MuxConfig] if it is a mux config.
    pub fn into_mux_config(self) -> Result<MuxConfig, serde_json::Error> {
        if self.0.is_null() {
            return Ok(Default::default());
        }
        self.from_value()
    }
}

impl From<serde_json::Value> for GethDebugTracerConfig {
    fn from(value: serde_json::Value) -> Self {
        Self(value)
    }
}

impl From<CallConfig> for GethDebugTracerConfig {
    fn from(value: CallConfig) -> Self {
        Self(serde_json::to_value(value).expect("is serializable"))
    }
}
impl From<FlatCallConfig> for GethDebugTracerConfig {
    fn from(value: FlatCallConfig) -> Self {
        Self(serde_json::to_value(value).expect("is serializable"))
    }
}

impl From<PreStateConfig> for GethDebugTracerConfig {
    fn from(value: PreStateConfig) -> Self {
        Self(serde_json::to_value(value).expect("is serializable"))
    }
}

impl From<MuxConfig> for GethDebugTracerConfig {
    fn from(value: MuxConfig) -> Self {
        Self(serde_json::to_value(value).expect("is serializable"))
    }
}

impl From<Erc7562Config> for GethDebugTracerConfig {
    fn from(value: Erc7562Config) -> Self {
        Self(serde_json::to_value(value).expect("is serializable"))
    }
}

/// Bindings for additional `debug_traceTransaction` options
///
/// See <https://geth.ethereum.org/docs/rpc/ns-debug#debug_tracetransaction>
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GethDebugTracingOptions {
    /// The common tracing options
    #[serde(default, flatten)]
    pub config: GethDefaultTracingOptions,
    /// The custom tracer to use.
    ///
    /// If `None` then the default structlog tracer is used.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tracer: Option<GethDebugTracerType>,
    /// Config specific to given `tracer`.
    ///
    /// Note default struct logger config is historically embedded in main object.
    ///
    /// tracerConfig is slated for Geth v1.11.0
    /// See <https://github.com/ethereum/go-ethereum/issues/26513>
    ///
    /// This could be [CallConfig] or [PreStateConfig] depending on the tracer.
    #[serde(default, skip_serializing_if = "GethDebugTracerConfig::is_null")]
    pub tracer_config: GethDebugTracerConfig,
    /// A Go duration string, such as `5s`, that overrides the default five-second timeout for
    /// JavaScript-based tracing calls.
    ///
    /// [`Self::with_timeout`] represents the supplied duration as integer milliseconds, for
    /// example `2500ms`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub timeout: Option<String>,
}

impl GethDebugTracingOptions {
    /// Creates a new instance with given [`GethDebugTracerType`] configured
    pub fn new_tracer(tracer: impl Into<GethDebugTracerType>) -> Self {
        Self::default().with_tracer(tracer.into())
    }

    /// Sets the tracer to use
    pub fn with_tracer(mut self, tracer: GethDebugTracerType) -> Self {
        self.tracer = Some(tracer);
        self
    }

    /// Creates new Options for [`GethDebugBuiltInTracerType::CallTracer`].
    pub fn call_tracer(config: CallConfig) -> Self {
        Self::new_tracer(GethDebugBuiltInTracerType::CallTracer).with_call_config(config)
    }

    /// Creates new Options for [`GethDebugBuiltInTracerType::FlatCallTracer`].
    pub fn flat_call_tracer(config: FlatCallConfig) -> Self {
        Self::new_tracer(GethDebugBuiltInTracerType::FlatCallTracer).with_config(config)
    }

    /// Creates new Options for [`GethDebugBuiltInTracerType::MuxTracer`].
    pub fn mux_tracer(config: MuxConfig) -> Self {
        Self::new_tracer(GethDebugBuiltInTracerType::MuxTracer).with_config(config)
    }

    /// Creates new options for [`GethDebugBuiltInTracerType::PreStateTracer`]
    pub fn prestate_tracer(config: PreStateConfig) -> Self {
        Self::new_tracer(GethDebugBuiltInTracerType::PreStateTracer).with_prestate_config(config)
    }

    /// Requests the EIP-8037 transaction gas breakdown as [`StateGasTrace`].
    /// Requires node support for `stateGasTracer`; selecting it does not activate EIP-8037.
    /// See the [gas accounting guide](crate::geth::state_gas) for fields and network support.
    pub fn state_gas_tracer() -> Self {
        Self::new_tracer(GethDebugBuiltInTracerType::StateGasTracer)
    }

    /// Creates new options for [`GethDebugBuiltInTracerType::FourByteTracer`]
    pub fn four_byte_tracer() -> Self {
        Self::new_tracer(GethDebugBuiltInTracerType::FourByteTracer)
    }

    /// Creates an [`GethDebugTracerType::JsTracer`] with the given js code.
    pub fn js_tracer(code: impl Into<String>) -> Self {
        Self::new_tracer(GethDebugTracerType::JsTracer(code.into()))
    }

    /// Creates new options for [`GethDebugBuiltInTracerType::Erc7562Tracer`]
    pub fn erc7562_tracer(config: Erc7562Config) -> Self {
        Self::new_tracer(GethDebugBuiltInTracerType::Erc7562Tracer).with_config(config)
    }

    /// Sets the timeout to use for tracing
    pub fn with_timeout(mut self, duration: Duration) -> Self {
        self.timeout = Some(format!("{}ms", duration.as_millis()));
        self
    }

    /// Configures a [CallConfig]
    pub fn with_call_config(mut self, config: CallConfig) -> Self {
        self.tracer_config = config.into();
        self
    }

    /// Configures a [PreStateConfig]
    pub fn with_prestate_config(mut self, config: PreStateConfig) -> Self {
        self.tracer_config = config.into();
        self
    }

    /// Sets the tracer config
    pub fn with_config<T>(mut self, config: T) -> Self
    where
        T: Into<GethDebugTracerConfig>,
    {
        self.tracer_config = config.into();
        self
    }
}

/// Default tracing options for the struct logger.
///
/// These are all known general purpose tracer options that may or not be supported by a given
/// tracer. For example, the `enableReturnData` option is a noop on regular
/// `debug_trace{Transaction,Block}` calls.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GethDefaultTracingOptions {
    /// enable memory capture
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub enable_memory: Option<bool>,
    /// Disable memory capture
    ///
    /// This is the opposite of `enable_memory`.
    ///
    /// Note: memory capture used to be enabled by default on geth, but has since been flipped <https://github.com/ethereum/go-ethereum/pull/23558> and is now disabled by default.
    /// However, at the time of writing this, Erigon still defaults to enabled and supports the
    /// `disableMemory` option. So we keep this option for compatibility, but if it's missing
    /// OR `enableMemory` is present `enableMemory` takes precedence.
    ///
    /// See also <https://github.com/paradigmxyz/reth/issues/3033>
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub disable_memory: Option<bool>,
    /// disable stack capture
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub disable_stack: Option<bool>,
    /// Disable storage capture
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub disable_storage: Option<bool>,
    /// Enable return data capture
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub enable_return_data: Option<bool>,
    /// Disable return data capture
    ///
    /// This is the opposite of `enable_return_data`, and only supported for compatibility reasons.
    /// See also `disable_memory`.
    ///
    /// If `enable_return_data` is present, `enable_return_data` always takes precedence.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub disable_return_data: Option<bool>,
    /// print output during capture end
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub debug: Option<bool>,
    /// maximum length of output, but zero means unlimited
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub limit: Option<u64>,
}

impl GethDefaultTracingOptions {
    /// Enables memory capture.
    pub const fn enable_memory(self) -> Self {
        self.with_enable_memory(true)
    }

    /// Disables memory capture.
    pub const fn disable_memory(self) -> Self {
        self.with_disable_memory(true)
    }

    /// Disables stack capture.
    pub const fn disable_stack(self) -> Self {
        self.with_disable_stack(true)
    }

    /// Disables storage capture.
    pub const fn disable_storage(self) -> Self {
        self.with_disable_storage(true)
    }

    /// Enables return data capture.
    pub const fn enable_return_data(self) -> Self {
        self.with_enable_return_data(true)
    }

    /// Disables return data capture.
    pub const fn disable_return_data(self) -> Self {
        self.with_disable_return_data(true)
    }

    /// Enables debug mode.
    pub const fn debug(self) -> Self {
        self.with_debug(true)
    }

    /// Sets the enable_memory field.
    pub const fn with_enable_memory(mut self, enable: bool) -> Self {
        self.enable_memory = Some(enable);
        self
    }

    /// Sets the disable_memory field.
    pub const fn with_disable_memory(mut self, disable: bool) -> Self {
        self.disable_memory = Some(disable);
        self
    }

    /// Sets the disable_stack field.
    pub const fn with_disable_stack(mut self, disable: bool) -> Self {
        self.disable_stack = Some(disable);
        self
    }

    /// Sets the disable_storage field.
    pub const fn with_disable_storage(mut self, disable: bool) -> Self {
        self.disable_storage = Some(disable);
        self
    }

    /// Sets the enable_return_data field.
    pub const fn with_enable_return_data(mut self, enable: bool) -> Self {
        self.enable_return_data = Some(enable);
        self
    }

    /// Sets the disable_return_data field.
    pub const fn with_disable_return_data(mut self, disable: bool) -> Self {
        self.disable_return_data = Some(disable);
        self
    }

    /// Sets the debug field.
    pub const fn with_debug(mut self, debug: bool) -> Self {
        self.debug = Some(debug);
        self
    }

    /// Sets the limit field.
    pub const fn with_limit(mut self, limit: u64) -> Self {
        self.limit = Some(limit);
        self
    }

    /// Returns `true` if return data capture is enabled
    pub fn is_return_data_enabled(&self) -> bool {
        self.enable_return_data
            .or_else(|| self.disable_return_data.map(|disable| !disable))
            .unwrap_or(false)
    }

    /// Returns `true` if memory capture is enabled
    pub fn is_memory_enabled(&self) -> bool {
        self.enable_memory.or_else(|| self.disable_memory.map(|disable| !disable)).unwrap_or(false)
    }

    /// Returns `true` if stack capture is enabled
    pub fn is_stack_enabled(&self) -> bool {
        !self.disable_stack.unwrap_or(false)
    }

    /// Returns `true` if storage capture is enabled
    pub fn is_storage_enabled(&self) -> bool {
        !self.disable_storage.unwrap_or(false)
    }
}

/// Bindings for additional `debug_traceCall` options
///
/// See <https://geth.ethereum.org/docs/rpc/ns-debug#debug_tracecall>
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GethDebugTracingCallOptions {
    /// All the options
    #[serde(flatten)]
    pub tracing_options: GethDebugTracingOptions,
    /// The state overrides to apply
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub state_overrides: Option<StateOverride>,
    /// The block overrides to apply
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub block_overrides: Option<BlockOverrides>,
    /// The transaction index to trace within the block.
    /// If set, the state at the given index will be used to trace the call.
    #[serde(default, skip_serializing_if = "Option::is_none", with = "alloy_serde::quantity::opt")]
    pub tx_index: Option<u64>,
}

impl GethDebugTracingCallOptions {
    /// Creates a new instance with the given tracing options
    pub const fn new(tracing_options: GethDebugTracingOptions) -> Self {
        Self { tracing_options, state_overrides: None, block_overrides: None, tx_index: None }
    }

    /// Enables state overrides
    pub fn with_state_overrides(mut self, overrides: StateOverride) -> Self {
        self.state_overrides = Some(overrides);
        self
    }

    /// Enables block overrides
    pub fn with_block_overrides(mut self, overrides: BlockOverrides) -> Self {
        self.block_overrides = Some(overrides);
        self
    }

    /// Sets the tracing options
    pub fn with_tracing_options(mut self, options: GethDebugTracingOptions) -> Self {
        self.tracing_options = options;
        self
    }

    /// Sets the tx index
    pub const fn with_tx_index(mut self, index: u64) -> Self {
        self.tx_index = Some(index);
        self
    }
}

impl From<GethDebugTracingOptions> for GethDebugTracingCallOptions {
    fn from(value: GethDebugTracingOptions) -> Self {
        Self::new(value)
    }
}

/// Serializes a storage map as a list of key-value pairs with 0x-prefix
fn serialize_string_storage_map_opt<S: Serializer>(
    storage: &Option<BTreeMap<B256, B256>>,
    s: S,
) -> Result<S::Ok, S::Error> {
    match storage {
        None => s.serialize_none(),
        Some(storage) => {
            let mut m = s.serialize_map(Some(storage.len()))?;
            for (key, val) in storage {
                let key = format!("{key:?}");
                let val = format!("{val:?}");
                m.serialize_entry(key.as_str(), val.as_str())?;
            }
            m.end()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use similar_asserts::assert_eq;

    #[test]
    fn serde_chain_block_trace_result() {
        let block_hash = B256::repeat_byte(0x11);
        let tx_hash = B256::repeat_byte(0x22);
        let result = ChainBlockTraceResult {
            block: U256::from(2),
            hash: block_hash,
            traces: vec![
                Some(TraceResult::Error {
                    error: "trace failed".to_string(),
                    tx_hash: Some(tx_hash),
                }),
                None,
            ],
        };

        assert_eq!(
            serde_json::to_value(result).unwrap(),
            serde_json::json!({
                "block": "0x2",
                "hash": block_hash,
                "traces": [
                    {"error": "trace failed", "txHash": tx_hash},
                    null
                ]
            })
        );
    }

    #[test]
    fn test_return_data_prefix() {
        let raw = r#"{
  "failed": false,
  "gas": 0,
  "returnValue": "",
  "structLogs": []
}"#;

        let frame = serde_json::from_str::<DefaultFrame>(raw).unwrap();
        assert_eq!(frame, DefaultFrame::default());
    }

    #[test]
    fn test_tracer_config() {
        let s = "{\"tracer\": \"callTracer\"}";
        let opts = serde_json::from_str::<GethDebugTracingOptions>(s).unwrap();
        assert_eq!(
            opts.tracer,
            Some(GethDebugTracerType::BuiltInTracer(GethDebugBuiltInTracerType::CallTracer))
        );
        let _call_config = opts.tracer_config.clone().into_call_config().unwrap();
        let _prestate_config = opts.tracer_config.into_pre_state_config().unwrap();
    }

    #[test]
    fn test_memory_capture() {
        let mut config = GethDefaultTracingOptions::default();

        // by default false
        assert!(!config.is_memory_enabled());

        config.disable_memory = Some(false);
        // disable == false -> enable
        assert!(config.is_memory_enabled());

        config.enable_memory = Some(false);
        // enable == false -> disable
        assert!(!config.is_memory_enabled());
    }

    #[test]
    fn test_return_data_capture() {
        let mut config = GethDefaultTracingOptions::default();

        // by default false
        assert!(!config.is_return_data_enabled());

        config.disable_return_data = Some(false);
        // disable == false -> enable
        assert!(config.is_return_data_enabled());

        config.enable_return_data = Some(false);
        // enable == false -> disable
        assert!(!config.is_return_data_enabled());
    }

    // <https://etherscan.io/tx/0xd01212e8ab48d2fd2ea9c4f33f8670fd1cf0cfb09d2e3c6ceddfaf54152386e5>
    #[test]
    fn serde_default_frame() {
        let input = include_str!("../../test_data/default/structlogs_01.json");
        let _frame: DefaultFrame = serde_json::from_str(input).unwrap();
    }

    #[test]
    fn test_serialize_storage_map() {
        let s = r#"{"pc":3349,"op":"SLOAD","gas":23959,"gasCost":2100,"depth":1,"stack":[],"memory":[],"storage":{"0x6693dabf5ec7ab1a0d1c5bc58451f85d5e44d504c9ffeb75799bfdb61aa2997a":"0x0000000000000000000000000000000000000000000000000000000000000000"}}"#;
        let log: StructLog = serde_json::from_str(s).unwrap();
        let val = serde_json::to_value(&log).unwrap();
        let input = serde_json::from_str::<serde_json::Value>(s).unwrap();
        assert_eq!(input, val);
    }

    #[test]
    fn test_trace_result_serde() {
        let s = r#"        {
            "result": {
                "from": "0xccc5499e15fedaaeaba68aeb79b95b20f725bc56",
                "gas": "0x186a0",
                "gasUsed": "0xdb91",
                "to": "0xdac17f958d2ee523a2206206994597c13d831ec7",
                "input": "0xa9059cbb000000000000000000000000e3f85a274c1edbea2f2498cf5978f41961cf8b5b0000000000000000000000000000000000000000000000000000000068c8f380",
                "value": "0x0",
                "type": "CALL"
            },
            "txHash": "0x7cc741c553d4098f319c894d9db208999ca49ee1b5c53f6a9992e687cbffb69e"
        }"#;
        let result: TraceResult = serde_json::from_str(s).unwrap();
        let hash = result.tx_hash().unwrap();
        assert_eq!(
            hash,
            "0x7cc741c553d4098f319c894d9db208999ca49ee1b5c53f6a9992e687cbffb69e"
                .parse::<B256>()
                .unwrap()
        );

        let de = serde_json::to_value(&result).unwrap();
        let val = serde_json::from_str::<serde_json::Value>(s).unwrap();
        assert_eq!(val, de);
    }

    #[test]
    fn test_geth_trace_into_tracer() {
        let geth_trace = GethTrace::Default(DefaultFrame::default());
        let inner = geth_trace.try_into_default_frame();
        assert!(inner.is_ok());

        let geth_trace = GethTrace::CallTracer(CallFrame::default());
        let inner = geth_trace.try_into_call_frame();
        assert!(inner.is_ok());

        let geth_trace = GethTrace::FourByteTracer(FourByteFrame::default());
        let inner = geth_trace.try_into_four_byte_frame();
        assert!(inner.is_ok());

        let geth_trace = GethTrace::PreStateTracer(PreStateFrame::Default(PreStateMode::default()));
        let inner = geth_trace.try_into_pre_state_frame();
        assert!(inner.is_ok());

        let geth_trace = GethTrace::NoopTracer(NoopFrame::default());
        let inner = geth_trace.try_into_noop_frame();
        assert!(inner.is_ok());

        let geth_trace = GethTrace::MuxTracer(MuxFrame::default());
        let inner = geth_trace.try_into_mux_frame();
        assert!(inner.is_ok());

        let geth_trace = GethTrace::Erc7562Tracer(Erc7562Frame::default());
        let inner = geth_trace.try_into_erc7562_frame();
        assert!(inner.is_ok());

        let geth_trace = GethTrace::JS(serde_json::Value::Null);
        let inner = geth_trace.try_into_json_value();
        assert!(inner.is_ok());
    }

    #[test]
    fn test_geth_trace_into_tracer_wrong_tracer() {
        let geth_trace = GethTrace::Default(DefaultFrame::default());
        let inner = geth_trace.try_into_call_frame();
        assert!(inner.is_err());
        assert!(matches!(inner, Err(UnexpectedTracerError(_))));
    }

    // <https://github.com/paradigmxyz/reth/issues/16289>
    #[test]
    fn test_deserde_json_debug_trace_call_json_tracer() {
        let s = include_str!("../../test_data/call_tracer/json-call-tracer16289.json");
        let opts: GethDebugTracingCallOptions = serde_json::from_str(s).unwrap();
        assert!(opts.tracing_options.tracer.unwrap().is_js());
    }

    #[test]
    fn deserde_jstracer() {
        let s = r#"{
      "tracer": "{fault: function(log) {}, step: function(log) { const memToHex = mem => mem.reduce((s, byte) => s + byte.toString(16).padStart(2, '0'), ''); }, result: function() { return this.data; }}"
      }"#;
        let _tracer = serde_json::from_str::<GethDebugTracingOptions>(s).unwrap();
    }

    #[test]
    fn serde_debug_tracing_call_options() {
        let opts = GethDebugTracingCallOptions {
            tracing_options: GethDebugTracingOptions {
                config: GethDefaultTracingOptions {
                    enable_return_data: Some(true),
                    ..Default::default()
                },
                tracer: Some(GethDebugTracerType::BuiltInTracer(
                    GethDebugBuiltInTracerType::PreStateTracer,
                )),
                tracer_config: GethDebugTracerConfig::default(),
                timeout: None,
            },
            state_overrides: None,
            block_overrides: None,
            tx_index: None,
        };

        let s = serde_json::to_string(&opts).unwrap();
        assert_eq!(s, r#"{"enableReturnData":true,"tracer":"prestateTracer"}"#);
        let from_json = serde_json::from_str::<GethDebugTracingCallOptions>(&s).unwrap();
        assert_eq!(opts, from_json);
    }

    #[test]
    fn serde_prestate_response() {
        let s = r#"[
        [
            {
                "0x0000000000000000000000000000000000000000": {
                    "balance": "0xcf13a3dbf538f7410"
                },
                "0x2ee4823855d1c4c0753ea19fd3548d64a79b73a5": {
                    "balance": "0x0"
                },
                "0x670b24610df99b1685aeac0dfd5307b92e0cf4d7": {
                    "balance": "0x38eaef3250efa03774",
                    "nonce": 2
                }
            }
        ]
    ]"#;

        let traces = serde_json::from_str::<Vec<Vec<GethTrace>>>(s).unwrap();
        assert!(traces[0][0].is_pre_state());
    }

    #[test]
    fn serde_geth_debug_tracing_options_prestate_tracer() {
        let s = r#"{
      "tracer": "prestateTracer",
      "tracerConfig": {
        "diffMode": true,
        "disableCode": true,
        "disableStorage": true
      }
    }"#;
        let opts: GethDebugTracingOptions = serde_json::from_str(s).unwrap();
        assert_eq!(
            opts.tracer,
            Some(GethDebugTracerType::BuiltInTracer(GethDebugBuiltInTracerType::PreStateTracer))
        );
        let config = opts.tracer_config.into_pre_state_config().unwrap();
        assert_eq!(config.diff_mode, Some(true));
        assert_eq!(config.disable_code, Some(true));
        assert_eq!(config.disable_storage, Some(true));
        assert!(!config.code_enabled());
    }
}
