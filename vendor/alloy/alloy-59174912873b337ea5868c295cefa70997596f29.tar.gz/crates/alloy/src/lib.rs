#![doc = include_str!("../README.md")]
#![doc(
    html_logo_url = "https://raw.githubusercontent.com/alloy-rs/core/main/assets/alloy.jpg",
    html_favicon_url = "https://raw.githubusercontent.com/alloy-rs/core/main/assets/favicon.ico"
)]
#![cfg_attr(not(test), warn(unused_crate_dependencies))]
#![cfg_attr(docsrs, feature(doc_cfg))]
#![cfg_attr(not(feature = "std"), no_std)]

/* --------------------------------------- Core re-exports -------------------------------------- */

// This should generally not be used by downstream crates as we re-export everything else
// individually. It is acceptable to use this if an item has been added to `alloy-core`
// and it has not been added to the re-exports below.
#[doc(hidden)]
pub use alloy_core as core;

/// Low-level primitives for Ethereum.
#[doc(inline)]
pub use self::core::primitives;
#[doc(no_inline)]
pub use primitives::{hex, uint};

/// Dynamic Solidity type encoder.
#[cfg(feature = "dyn-abi")]
#[doc(inline)]
pub use self::core::dyn_abi;

/// Full Ethereum [JSON-ABI](https://docs.soliditylang.org/en/latest/abi-spec.html) implementation.
#[cfg(feature = "json-abi")]
#[doc(inline)]
pub use self::core::json_abi;

/// Solidity type modeling and [ABI] and [EIP-712] codec implementation.
///
/// [ABI]: https://docs.soliditylang.org/en/latest/abi-spec.html
/// [EIP-712]: https://eips.ethereum.org/EIPS/eip-712
#[cfg(feature = "sol-types")]
#[doc(inline)]
pub use self::core::sol_types;

// Show this re-export in docs instead of the wrapper below.
#[cfg(all(doc, feature = "sol-types"))]
#[doc(no_inline)]
pub use sol_types::sol;

/// A fast and simple [Ethereum RLP][rlp] implementation in Rust.
///
/// [rlp]: https://ethereum.org/en/developers/docs/data-structures-and-encoding/rlp
#[cfg(feature = "rlp")]
#[doc(inline)]
pub use self::core::rlp;

/// [`sol!`](sol_types::sol!) `macro_rules!` wrapper to set import attributes.
///
/// See [`sol!`](sol_types::sol!) for the actual macro documentation.
#[cfg(all(not(doc), feature = "sol-types"))] // Show the actual macro in docs.
#[macro_export]
macro_rules! sol {
    ($($t:tt)*) => {
        $crate::sol_types::sol! {
            #![sol(alloy_sol_types = $crate::sol_types, alloy_contract = $crate::contract)]
            $($t)*
        }
    };
}

/* --------------------------------------- Main re-exports -------------------------------------- */

/// Interact with on-chain contracts.
#[cfg(feature = "contract")]
#[doc(inline)]
pub use alloy_contract as contract;

/// Ethereum consensus interface.
#[cfg(feature = "consensus")]
#[doc(inline)]
pub use alloy_consensus as consensus;

/// Ethereum Improvement Proposal (EIP) implementations.
#[cfg(feature = "eips")]
#[doc(inline)]
pub use alloy_eips as eips;

/// Ethereum Name Service utilities like namehash, forward & reverse lookups. ENS Name
/// resolving utilities.
#[cfg(feature = "ens")]
#[doc(inline)]
pub use alloy_ens as ens;

/// Ethereum blockchain RPC behavior abstraction.
#[cfg(feature = "network")]
#[doc(inline)]
pub use alloy_network as network;

/// Ethereum genesis file definitions.
#[cfg(feature = "genesis")]
#[doc(inline)]
pub use alloy_genesis as genesis;

/// Ethereum execution-layer client bindings.
///
/// Enable the `node-bindings` feature to access this re-export.
/// For `ProviderBuilder::connect_anvil*` in `alloy::providers`, enable
/// `provider-anvil-node` or combine `providers` with `node-bindings`.
#[cfg(feature = "node-bindings")]
#[cfg_attr(docsrs, doc(cfg(feature = "node-bindings")))]
#[doc(inline)]
pub use alloy_node_bindings as node_bindings;

/// Interface with an Ethereum blockchain.
///
/// See [`alloy_provider`] for more details.
#[cfg(feature = "providers")]
pub mod providers {
    #[doc(inline)]
    pub use alloy_provider::*;
}

/// Ethereum JSON-RPC publish-subscribe tower service and type definitions.
///
/// You will likely not need to use this module;
/// see the [`providers`] module for high-level usage of pubsub.
///
/// See [`alloy_pubsub`] for more details.
#[doc = "\n"] // Empty doc line `///` gets deleted by rustfmt.
#[cfg_attr(feature = "providers", doc = "[`providers`]: crate::providers")]
#[cfg_attr(
    not(feature = "providers"),
    doc = "[`providers`]: https://github.com/alloy-rs/alloy/tree/main/crates/provider"
)]
#[cfg(feature = "pubsub")]
pub mod pubsub {
    #[doc(inline)]
    pub use alloy_pubsub::*;
}

/// Ethereum JSON-RPC client and types.
#[cfg(feature = "rpc")]
pub mod rpc {
    #[cfg(feature = "rpc-client")]
    #[doc(inline)]
    pub use alloy_rpc_client as client;

    #[cfg(feature = "json-rpc")]
    #[doc(inline)]
    pub use alloy_json_rpc as json_rpc;

    /// Ethereum JSON-RPC type definitions.
    #[cfg(feature = "rpc-types")]
    #[doc(inline)]
    pub use alloy_rpc_types as types;
}

/// Serde related helpers for Alloy.
#[cfg(feature = "serde")]
#[doc(inline)]
pub use alloy_serde as serde;

/// Ethereum signer abstraction and implementations.
///
/// See [`alloy_signer`] for more details.
#[cfg(feature = "signers")]
pub mod signers {
    #[doc(inline)]
    pub use alloy_signer::*;

    #[cfg(feature = "signer-aws")]
    #[doc(inline)]
    pub use alloy_signer_aws as aws;

    #[cfg(feature = "signer-gcp")]
    #[doc(inline)]
    pub use alloy_signer_gcp as gcp;

    #[cfg(feature = "signer-ledger")]
    #[doc(inline)]
    pub use alloy_signer_ledger as ledger;

    #[cfg(feature = "signer-local")]
    #[doc(inline)]
    pub use alloy_signer_local as local;

    #[cfg(feature = "signer-trezor")]
    #[doc(inline)]
    pub use alloy_signer_trezor as trezor;

    #[cfg(feature = "signer-turnkey")]
    #[doc(inline)]
    pub use alloy_signer_turnkey as turnkey;
}

/// Low-level Ethereum JSON-RPC transport abstraction and implementations.
///
/// You will likely not need to use this module;
/// see the [`providers`] module for high-level usage of transports.
///
/// See [`alloy_transport`] for more details.
#[doc = "\n"] // Empty doc line `///` gets deleted by rustfmt.
#[cfg_attr(feature = "providers", doc = "[`providers`]: crate::providers")]
#[cfg_attr(
    not(feature = "providers"),
    doc = "[`providers`]: https://github.com/alloy-rs/alloy/tree/main/crates/provider"
)]
#[cfg(feature = "transports")]
pub mod transports {
    #[doc(inline)]
    pub use alloy_transport::*;

    #[cfg(feature = "transport-http")]
    #[doc(inline)]
    pub use alloy_transport_http as http;

    #[cfg(feature = "transport-ipc")]
    #[doc(inline)]
    pub use alloy_transport_ipc as ipc;

    #[cfg(feature = "transport-ws-base")]
    #[doc(inline)]
    pub use alloy_transport_ws as ws;
}

/// Fast Merkle-Patricia Trie (MPT) state root calculator and proof generator
/// for prefix-sorted nibbles.
///
/// See [`alloy_trie`] for more details.
#[cfg(feature = "trie")]
pub use alloy_trie as trie;
