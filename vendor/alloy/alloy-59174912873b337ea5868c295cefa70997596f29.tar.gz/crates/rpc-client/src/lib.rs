#![doc = include_str!("../README.md")]
#![doc(
    html_logo_url = "https://raw.githubusercontent.com/alloy-rs/core/main/assets/alloy.jpg",
    html_favicon_url = "https://raw.githubusercontent.com/alloy-rs/core/main/assets/favicon.ico"
)]
#![cfg_attr(not(test), warn(unused_crate_dependencies))]
#![cfg_attr(docsrs, feature(doc_cfg))]

#[macro_use]
extern crate tracing;

mod batch;
pub use batch::{BatchRequest, Waiter};

mod builder;
pub use builder::ClientBuilder;

mod builtin;
pub use builtin::{BuiltInConnectionString, ConnectionConfig};

mod call;
pub use call::RpcCall;

mod client;
pub use client::{ClientRef, NoParams, RpcClient, RpcClientInner, WeakClient};

mod poller;
pub use poller::{PollChannel, PollerBuilder, PollerStream};

#[cfg(feature = "ws-base")]
pub use alloy_transport_ws::WsConnect;

#[cfg(all(feature = "ws-base", not(target_family = "wasm")))]
pub use alloy_transport_ws::WebSocketConfig;

#[cfg(all(feature = "ipc", not(target_family = "wasm")))]
pub use alloy_transport_ipc::IpcConnect;

/// A client using a [`reqwest`] HTTP transport.
#[cfg(all(feature = "reqwest", not(all(target_os = "wasi", target_env = "p1"))))]
pub type ReqwestClient = RpcClient;
