//! This module extends the Ethereum JSON-RPC provider with the Debug namespace's RPC methods.
use crate::Provider;
use alloy_json_rpc::RpcRecv;
use alloy_network::{Ethereum, Network};
use alloy_primitives::{hex, Bytes, TxHash, B256};
use alloy_rpc_types_debug::ExecutionWitness;
use alloy_rpc_types_eth::{BadBlock, BlockId, BlockNumberOrTag, Bundle, StateContext};
use alloy_rpc_types_trace::geth::{
    BlockTraceResult, CallFrame, GethDebugTracingCallOptions, GethDebugTracingOptions, GethTrace,
    PreStateFrame, TraceResult,
};
use alloy_transport::TransportResult;

/// Debug namespace rpc interface that gives access to several non-standard RPC methods.
#[cfg_attr(target_family = "wasm", async_trait::async_trait(?Send))]
#[cfg_attr(not(target_family = "wasm"), async_trait::async_trait)]
pub trait DebugApi<N: Network = Ethereum>: Send + Sync {
    /// Returns an RLP-encoded header.
    async fn debug_get_raw_header(&self, block: BlockId) -> TransportResult<Bytes>;

    /// Retrieves and returns the RLP encoded block by number, hash or tag.
    async fn debug_get_raw_block(&self, block: BlockId) -> TransportResult<Bytes>;

    /// Returns an EIP-2718 binary-encoded transaction.
    async fn debug_get_raw_transaction(&self, hash: TxHash) -> TransportResult<Bytes>;

    /// Returns an array of EIP-2718 binary-encoded receipts.
    async fn debug_get_raw_receipts(&self, block: BlockId) -> TransportResult<Vec<Bytes>>;

    /// Returns an array of recent bad blocks that the client has seen on the network.
    async fn debug_get_bad_blocks(&self) -> TransportResult<Vec<BadBlock>>;

    /// Returns the structured logs created during the execution of EVM between two blocks
    /// (excluding start) as a JSON object.
    async fn debug_trace_chain(
        &self,
        start_exclusive: BlockNumberOrTag,
        end_inclusive: BlockNumberOrTag,
    ) -> TransportResult<Vec<BlockTraceResult>>;

    /// The debug_traceBlock method will return a full stack trace of all invoked opcodes of all
    /// transaction that were included in this block.
    ///
    /// This expects an RLP-encoded block.
    ///
    /// # Note
    ///
    /// The parent of this block must be present, or it will fail.
    async fn debug_trace_block(
        &self,
        rlp_block: &[u8],
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<Vec<TraceResult>>;

    /// Reruns the transaction specified by the hash and returns the trace.
    ///
    /// It will replay any prior transactions to achieve the same state the transaction was executed
    /// in.
    ///
    /// [`GethDebugTracingOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_transaction(
        &self,
        hash: TxHash,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<GethTrace>;

    /// Reruns the transaction specified by the hash and returns the trace in a specified format.
    ///
    /// This method allows for the trace to be returned as a type that implements `RpcRecv` and
    /// `serde::de::DeserializeOwned`.
    ///
    /// [`GethDebugTracingOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_transaction_as<R>(
        &self,
        hash: TxHash,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<R>
    where
        R: RpcRecv + serde::de::DeserializeOwned;

    /// Reruns the transaction specified by the hash and returns the trace as a JSON object.
    ///
    /// This method provides the trace in a JSON format, which can be useful for further processing
    /// or inspection.
    ///
    /// [`GethDebugTracingOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_transaction_js(
        &self,
        hash: TxHash,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<serde_json::Value>;

    /// Reruns the transaction specified by the hash and returns the trace as a call frame.
    ///
    /// This method provides the trace in the form of a `CallFrame`, which can be useful for
    /// analyzing the call stack and execution details.
    ///
    /// [`GethDebugTracingOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_transaction_call(
        &self,
        hash: TxHash,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<CallFrame>;

    /// Reruns the transaction specified by the hash and returns the trace in a specified format.
    ///
    /// This method allows for the trace to be returned as a type that implements `RpcRecv` and
    /// `serde::de::DeserializeOwned`.
    ///
    /// [`GethDebugTracingCallOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_call_as<R>(
        &self,
        tx: N::TransactionRequest,
        block: BlockId,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<R>
    where
        R: RpcRecv + serde::de::DeserializeOwned;

    /// Reruns the transaction specified by the hash and returns the trace as a JSON object.
    ///
    /// This method provides the trace in a JSON format, which can be useful for further processing
    /// or inspection.
    ///
    /// [`GethDebugTracingCallOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_call_js(
        &self,
        tx: N::TransactionRequest,
        block: BlockId,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<serde_json::Value>;

    /// Reruns the transaction specified by the hash and returns the trace as a call frame.
    ///
    /// This method provides the trace in the form of a `CallFrame`, which can be useful for
    /// analyzing the call stack and execution details.
    ///
    /// [`GethDebugTracingCallOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_call_callframe(
        &self,
        tx: N::TransactionRequest,
        block: BlockId,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<CallFrame>;

    /// Reruns the transaction specified by the hash and returns the pre-state trace.
    ///
    /// This method provides the trace in the form of a `PreStateFrame`, which can be useful for
    /// analyzing the state before execution.
    ///
    /// [`GethDebugTracingCallOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_call_prestate(
        &self,
        tx: N::TransactionRequest,
        block: BlockId,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<PreStateFrame>;

    /// Return a full stack trace of all invoked opcodes of all transaction that were included in
    /// this block.
    ///
    /// The parent of the block must be present or it will fail.
    ///
    /// [`GethDebugTracingOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_block_by_hash(
        &self,
        block: B256,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<Vec<TraceResult>>;

    /// Same as `debug_trace_block_by_hash` but block is specified by number.
    ///
    /// [`GethDebugTracingOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_block_by_number(
        &self,
        block: BlockNumberOrTag,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<Vec<TraceResult>>;

    /// Executes the given transaction without publishing it like `eth_call` and returns the trace
    /// of the execution.
    ///
    /// The transaction will be executed in the context of the given block number or tag.
    /// The state its run on is the state of the previous block.
    ///
    /// [`GethDebugTracingCallOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    ///
    /// Not all nodes support this call.
    async fn debug_trace_call(
        &self,
        tx: N::TransactionRequest,
        block: BlockId,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<GethTrace>;

    /// Same as `debug_trace_call` but it used to run and trace multiple transactions at once.
    ///
    /// [`GethDebugTracingCallOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_call_many(
        &self,
        bundles: Vec<Bundle>,
        state_context: StateContext,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<Vec<Vec<GethTrace>>>;

    /// Same as `debug_trace_call_many` but returns the traces as a type that implements `RpcRecv`.
    ///
    /// This method allows for the traces to be returned as a type that implements `RpcRecv` and
    /// `serde::de::DeserializeOwned`.
    ///
    /// [`GethDebugTracingCallOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_call_many_as<R>(
        &self,
        bundles: Vec<Bundle>,
        state_context: StateContext,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<Vec<Vec<R>>>
    where
        R: RpcRecv + serde::de::DeserializeOwned;

    /// Same as `debug_trace_call_many` but returns the traces as JSON objects.
    ///
    /// This method provides the traces in a JSON format, which can be useful for further processing
    /// or inspection.
    ///
    /// [`GethDebugTracingCallOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_call_many_js(
        &self,
        bundles: Vec<Bundle>,
        state_context: StateContext,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<Vec<Vec<serde_json::Value>>>;

    /// Same as `debug_trace_call_many` but returns the traces as call frames.
    ///
    /// This method provides the traces in the form of `CallFrame`s, which can be useful for
    /// analyzing the call stack and execution details.
    ///
    /// [`GethDebugTracingCallOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_call_many_callframe(
        &self,
        bundles: Vec<Bundle>,
        state_context: StateContext,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<Vec<Vec<CallFrame>>>;

    /// Same as `debug_trace_call_many` but returns the pre-state traces.
    ///
    /// This method provides the traces in the form of `PreStateFrame`s, which can be useful for
    /// analyzing the state before execution.
    ///
    /// [`GethDebugTracingCallOptions`] can be used to specify the trace options.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_trace_call_many_prestate(
        &self,
        bundles: Vec<Bundle>,
        state_context: StateContext,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<Vec<Vec<PreStateFrame>>>;

    /// The `debug_executionWitness` method allows for re-execution of a block with the purpose of
    /// generating an execution witness. The witness contains lists of required preimages and
    /// headers needed during execution and verification: state trie node preimages (`state`),
    /// contract code preimages (`codes`), unhashed account/storage keys (`keys`), and
    /// RLP-encoded block headers (`headers`) used to verify state reads and BLOCKHASH results.
    ///
    /// The first argument is the block number or block hash.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_execution_witness(
        &self,
        block: BlockNumberOrTag,
    ) -> TransportResult<ExecutionWitness>;

    /// The `debug_codeByHash` method returns the code associated with a given hash at the specified
    /// block. If no code is found, it returns None. If no block is provided, it defaults to the
    /// latest block.
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    async fn debug_code_by_hash(
        &self,
        hash: B256,
        block: Option<BlockId>,
    ) -> TransportResult<Option<Bytes>>;

    /// The `debug_dbGet` method retrieves a value from the database using the given key.
    ///
    /// The key can be provided in two formats:
    /// - Hex-encoded string with `0x` prefix: `0x[hex_string]` - decoded as hex bytes
    /// - Raw byte string without `0x` prefix: `[raw_byte_string]` - treated as raw bytes
    ///
    /// # Note
    ///
    /// Not all nodes support this call.
    ///
    /// # References
    /// - [Reth implementation](https://github.com/paradigmxyz/reth/pull/19369)
    /// - [Geth schema](https://github.com/ethereum/go-ethereum/blob/737ffd1bf0cbee378d0111a5b17ae4724fb2216c/core/rawdb/schema.go#L29)
    async fn debug_db_get(&self, key: &str) -> TransportResult<Bytes>;
}

#[cfg_attr(target_family = "wasm", async_trait::async_trait(?Send))]
#[cfg_attr(not(target_family = "wasm"), async_trait::async_trait)]
impl<N, P> DebugApi<N> for P
where
    N: Network,
    P: Provider<N>,
{
    async fn debug_get_raw_header(&self, block: BlockId) -> TransportResult<Bytes> {
        self.client().request("debug_getRawHeader", (block,)).await
    }

    async fn debug_get_raw_block(&self, block: BlockId) -> TransportResult<Bytes> {
        self.client().request("debug_getRawBlock", (block,)).await
    }

    async fn debug_get_raw_transaction(&self, hash: TxHash) -> TransportResult<Bytes> {
        self.client().request("debug_getRawTransaction", (hash,)).await
    }

    async fn debug_get_raw_receipts(&self, block: BlockId) -> TransportResult<Vec<Bytes>> {
        self.client().request("debug_getRawReceipts", (block,)).await
    }

    async fn debug_get_bad_blocks(&self) -> TransportResult<Vec<BadBlock>> {
        self.client().request_noparams("debug_getBadBlocks").await
    }

    async fn debug_trace_chain(
        &self,
        start_exclusive: BlockNumberOrTag,
        end_inclusive: BlockNumberOrTag,
    ) -> TransportResult<Vec<BlockTraceResult>> {
        self.client().request("debug_traceChain", (start_exclusive, end_inclusive)).await
    }

    async fn debug_trace_block(
        &self,
        rlp_block: &[u8],
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<Vec<TraceResult>> {
        let rlp_block = hex::encode_prefixed(rlp_block);
        self.client().request("debug_traceBlock", (rlp_block, trace_options)).await
    }

    async fn debug_trace_transaction(
        &self,
        hash: TxHash,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<GethTrace> {
        self.client().request("debug_traceTransaction", (hash, trace_options)).await
    }

    async fn debug_trace_transaction_as<R>(
        &self,
        hash: TxHash,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<R>
    where
        R: RpcRecv,
    {
        self.client().request("debug_traceTransaction", (hash, trace_options)).await
    }

    async fn debug_trace_transaction_js(
        &self,
        hash: TxHash,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<serde_json::Value> {
        self.debug_trace_transaction_as::<serde_json::Value>(hash, trace_options).await
    }

    async fn debug_trace_transaction_call(
        &self,
        hash: TxHash,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<CallFrame> {
        self.debug_trace_transaction_as::<CallFrame>(hash, trace_options).await
    }

    async fn debug_trace_call_as<R>(
        &self,
        tx: N::TransactionRequest,
        block: BlockId,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<R>
    where
        R: RpcRecv,
    {
        self.client().request("debug_traceCall", (tx, block, trace_options)).await
    }

    async fn debug_trace_call_js(
        &self,
        tx: N::TransactionRequest,
        block: BlockId,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<serde_json::Value> {
        self.debug_trace_call_as::<serde_json::Value>(tx, block, trace_options).await
    }

    async fn debug_trace_call_callframe(
        &self,
        tx: N::TransactionRequest,
        block: BlockId,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<CallFrame> {
        self.debug_trace_call_as::<CallFrame>(tx, block, trace_options).await
    }

    async fn debug_trace_call_prestate(
        &self,
        tx: N::TransactionRequest,
        block: BlockId,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<PreStateFrame> {
        self.debug_trace_call_as::<PreStateFrame>(tx, block, trace_options).await
    }

    async fn debug_trace_block_by_hash(
        &self,
        block: B256,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<Vec<TraceResult>> {
        self.client().request("debug_traceBlockByHash", (block, trace_options)).await
    }

    async fn debug_trace_block_by_number(
        &self,
        block: BlockNumberOrTag,
        trace_options: GethDebugTracingOptions,
    ) -> TransportResult<Vec<TraceResult>> {
        self.client().request("debug_traceBlockByNumber", (block, trace_options)).await
    }

    async fn debug_trace_call(
        &self,
        tx: N::TransactionRequest,
        block: BlockId,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<GethTrace> {
        self.client().request("debug_traceCall", (tx, block, trace_options)).await
    }

    async fn debug_trace_call_many(
        &self,
        bundles: Vec<Bundle>,
        state_context: StateContext,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<Vec<Vec<GethTrace>>> {
        self.client().request("debug_traceCallMany", (bundles, state_context, trace_options)).await
    }

    async fn debug_trace_call_many_as<R>(
        &self,
        bundles: Vec<Bundle>,
        state_context: StateContext,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<Vec<Vec<R>>>
    where
        R: RpcRecv,
    {
        self.client().request("debug_traceCallMany", (bundles, state_context, trace_options)).await
    }

    async fn debug_trace_call_many_js(
        &self,
        bundles: Vec<Bundle>,
        state_context: StateContext,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<Vec<Vec<serde_json::Value>>> {
        self.debug_trace_call_many_as::<serde_json::Value>(bundles, state_context, trace_options)
            .await
    }

    async fn debug_trace_call_many_callframe(
        &self,
        bundles: Vec<Bundle>,
        state_context: StateContext,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<Vec<Vec<CallFrame>>> {
        self.debug_trace_call_many_as::<CallFrame>(bundles, state_context, trace_options).await
    }

    async fn debug_trace_call_many_prestate(
        &self,
        bundles: Vec<Bundle>,
        state_context: StateContext,
        trace_options: GethDebugTracingCallOptions,
    ) -> TransportResult<Vec<Vec<PreStateFrame>>> {
        self.debug_trace_call_many_as::<PreStateFrame>(bundles, state_context, trace_options).await
    }

    async fn debug_execution_witness(
        &self,
        block: BlockNumberOrTag,
    ) -> TransportResult<ExecutionWitness> {
        self.client().request("debug_executionWitness", (block,)).await
    }

    async fn debug_code_by_hash(
        &self,
        hash: B256,
        block: Option<BlockId>,
    ) -> TransportResult<Option<Bytes>> {
        self.client().request("debug_codeByHash", (hash, block)).await
    }

    async fn debug_db_get(&self, key: &str) -> TransportResult<Bytes> {
        self.client().request("debug_dbGet", (key,)).await
    }
}

#[cfg(test)]
mod test {
    use super::*;
    use crate::{ext::test::async_ci_only, ProviderBuilder, WalletProvider};
    use alloy_network::TransactionBuilder;
    use alloy_node_bindings::{utils::run_with_tempdir, Geth, Reth};
    use alloy_primitives::{address, U256};
    use alloy_rpc_types_eth::TransactionRequest;

    #[tokio::test]
    async fn test_debug_trace_transaction() {
        async_ci_only(|| async move {
            let provider = ProviderBuilder::new().connect_anvil_with_wallet();
            let from = provider.default_signer_address();

            let gas_price = provider.get_gas_price().await.unwrap();
            let tx = TransactionRequest::default()
                .from(from)
                .to(address!("deadbeef00000000deadbeef00000000deadbeef"))
                .value(U256::from(100))
                .max_fee_per_gas(gas_price + 1)
                .max_priority_fee_per_gas(gas_price + 1);
            let pending = provider.send_transaction(tx).await.unwrap();
            let receipt = pending.get_receipt().await.unwrap();

            let hash = receipt.transaction_hash;
            let trace_options = GethDebugTracingOptions::default();

            let trace = provider.debug_trace_transaction(hash, trace_options).await.unwrap();

            if let GethTrace::Default(trace) = trace {
                assert_eq!(trace.gas, 21000)
            }
        })
        .await;
    }

    #[tokio::test]
    async fn test_debug_trace_call() {
        async_ci_only(|| async move {
            let provider = ProviderBuilder::new().connect_anvil_with_wallet();
            let from = provider.default_signer_address();
            let gas_price = provider.get_gas_price().await.unwrap();
            let tx = TransactionRequest::default()
                .from(from)
                .with_input("0xdeadbeef")
                .max_fee_per_gas(gas_price + 1)
                .max_priority_fee_per_gas(gas_price + 1);

            let trace = provider
                .debug_trace_call(
                    tx,
                    BlockNumberOrTag::Latest.into(),
                    GethDebugTracingCallOptions::default(),
                )
                .await
                .unwrap();

            if let GethTrace::Default(trace) = trace {
                assert!(!trace.struct_logs.is_empty());
            }
        })
        .await;
    }

    #[tokio::test]
    async fn call_debug_get_raw_header() {
        async_ci_only(|| async move {
            run_with_tempdir("geth-test-", |temp_dir| async move {
                let geth = Geth::new().disable_discovery().data_dir(temp_dir).spawn();
                let provider = ProviderBuilder::new().connect_http(geth.endpoint_url());

                let rlp_header = provider
                    .debug_get_raw_header(BlockId::Number(BlockNumberOrTag::Latest))
                    .await
                    .expect("debug_getRawHeader call should succeed");

                assert!(!rlp_header.is_empty());
            })
            .await;
        })
        .await;
    }

    #[tokio::test]
    async fn call_debug_get_raw_block() {
        async_ci_only(|| async move {
            run_with_tempdir("geth-test-", |temp_dir| async move {
                let geth = Geth::new().disable_discovery().data_dir(temp_dir).spawn();
                let provider = ProviderBuilder::new().connect_http(geth.endpoint_url());

                let rlp_block = provider
                    .debug_get_raw_block(BlockId::Number(BlockNumberOrTag::Latest))
                    .await
                    .expect("debug_getRawBlock call should succeed");

                assert!(!rlp_block.is_empty());
            })
            .await;
        })
        .await;
    }

    #[tokio::test]
    async fn call_debug_get_raw_receipts() {
        async_ci_only(|| async move {
            run_with_tempdir("geth-test-", |temp_dir| async move {
                let geth = Geth::new().disable_discovery().data_dir(temp_dir).spawn();
                let provider = ProviderBuilder::new().connect_http(geth.endpoint_url());

                let result = provider
                    .debug_get_raw_receipts(BlockId::Number(BlockNumberOrTag::Latest))
                    .await;
                assert!(result.is_ok());
            })
            .await;
        })
        .await;
    }

    #[tokio::test]
    async fn call_debug_get_bad_blocks() {
        async_ci_only(|| async move {
            run_with_tempdir("geth-test-", |temp_dir| async move {
                let geth = Geth::new().disable_discovery().data_dir(temp_dir).spawn();
                let provider = ProviderBuilder::new().connect_http(geth.endpoint_url());

                let result = provider.debug_get_bad_blocks().await;
                assert!(result.is_ok());
            })
            .await;
        })
        .await;
    }

    #[tokio::test]
    #[cfg_attr(windows, ignore = "no reth on windows")]
    async fn debug_trace_call_many() {
        async_ci_only(|| async move {
            run_with_tempdir("reth-test-", |temp_dir| async move {
                let reth = Reth::new().dev().disable_discovery().data_dir(temp_dir).spawn();
                let provider = ProviderBuilder::new().connect_http(reth.endpoint_url());

                let tx1 = TransactionRequest::default()
                    .with_from(address!("0000000000000000000000000000000000000123"))
                    .with_to(address!("0000000000000000000000000000000000000456"));

                let tx2 = TransactionRequest::default()
                    .with_from(address!("0000000000000000000000000000000000000456"))
                    .with_to(address!("0000000000000000000000000000000000000789"));

                let bundles = vec![Bundle { transactions: vec![tx1, tx2], block_override: None }];
                let state_context = StateContext::default();
                let trace_options = GethDebugTracingCallOptions::default();
                let result =
                    provider.debug_trace_call_many(bundles, state_context, trace_options).await;
                assert!(result.is_ok());

                let traces = result.unwrap();
                assert_eq!(
                    serde_json::to_string_pretty(&traces).unwrap().trim(),
                    r#"
[
  [
    {
      "failed": false,
      "gas": 21000,
      "returnValue": "0x",
      "structLogs": []
    },
    {
      "failed": false,
      "gas": 21000,
      "returnValue": "0x",
      "structLogs": []
    }
  ]
]
"#
                    .trim(),
                );
            })
            .await;
        })
        .await;
    }

    #[tokio::test]
    #[cfg_attr(windows, ignore = "no reth on windows")]
    async fn test_debug_code_by_hash() {
        use alloy_primitives::b256;

        async_ci_only(|| async move {
            run_with_tempdir("reth-test-", |temp_dir| async move {
                let reth = Reth::new().dev().disable_discovery().data_dir(temp_dir).spawn();
                let provider = ProviderBuilder::new().connect_http(reth.endpoint_url());

                // Test 1: Empty code hash (keccak256 of empty bytes)
                // This is a valid hash that exists for EOA accounts
                let empty_code_hash =
                    b256!("c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470");
                let empty_code = provider.debug_code_by_hash(empty_code_hash, None).await.unwrap();
                // Reth might return Some(empty) or None for empty code
                if let Some(code) = empty_code {
                    assert!(
                        code.is_empty() || code == Bytes::from_static(&[]),
                        "Empty code hash should return empty bytes"
                    );
                }

                // Test 2: Non-existent hash should return None
                let non_existent_hash =
                    b256!("0000000000000000000000000000000000000000000000000000000000000001");
                let no_code = provider.debug_code_by_hash(non_existent_hash, None).await.unwrap();
                assert!(no_code.is_none(), "Non-existent hash should return None");

                // Test 3: Verify the API is callable and doesn't error
                // This confirms Reth has the method implemented
                let another_hash =
                    b256!("1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef");
                let result = provider.debug_code_by_hash(another_hash, None).await;
                assert!(result.is_ok(), "API call should not error even for random hashes");
            })
            .await;
        })
        .await;
    }
}
